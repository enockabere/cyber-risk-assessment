import { type Config } from "tailwindcss";
import shadcnPlugin from "@shadcn/ui/plugin";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: "#14532d", // Deep Green
          light: "#22c55e", // Lime Green
          dark: "#0f291e", // Darker Green
        },
        accent: {
          DEFAULT: "#0ea5e9", // Sky Blue
          dark: "#0369a1", // Dark Blue
        },
        background: "#f1f5f9", // Light Gray BG
        foreground: "#1e293b", // Text color
      },
    },
  },
  plugins: [shadcnPlugin],
};

export default config;
